<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Post; 
use App\Observers\PostObserver;

class PostModelServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        Post::observe(PostObserver::class);

    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
