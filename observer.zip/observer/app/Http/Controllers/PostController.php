<?php

namespace App\Http\Controllers;

use App\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    
    public function edit($id, Request $request)
    {
        $post = Post::find($id);

        $post->title = $request->input('title');
        $post->description = $request->input('description');

        $post->save();
    }
}